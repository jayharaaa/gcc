function adobenuker {
    <#
    .SYNOPSIS
        Downloads and runs adobe creative cloud cleaner
    #>
    try {
        $ACCC_filepath = "$ENV:temp\AdobeCreativeCloudCleanerTool.exe"
        $Initial_ProgressPreference = $ProgressPreference
        $ProgressPreference = "SilentlyContinue" # Disables the Progress Bar to drastically speed up Invoke-WebRequest
        Invoke-WebRequest -Uri "https://swupmf.adobe.com/webfeed/CleanerTool/win/AdobeCreativeCloudCleanerTool.exe" -OutFile $ACCC_filepath
        Write-Host "Starting Adobe Creative Cloud Cleaner ..."
        Start-Process $ACCC_filepath
    }
    catch {
        Write-Host "Error Downloading and Running Adobe Creative Cloud Cleaner" -ForegroundColor Red
    }
    finally {
        $ProgressPreference = $Initial_ProgressPreference
    }
}

# Call the function (optional)
adobenuker