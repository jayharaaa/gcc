# Define the shortcut properties
$shortcutName = "glizzwald's clutter cleanup tool"
$desktopPath = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path -Path $desktopPath -ChildPath "$shortcutName.lnk"
$targetPath = "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe"
$arguments = "-ExecutionPolicy Bypass -Command `"irm https://github.com/jayharaaa/gcc/raw/main/gccrunner.ps1 | iex`""
$workingDirectory = "$env:windir\system32"
$iconPath = "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe"

# Create the WScript.Shell COM object
$wshShell = New-Object -ComObject WScript.Shell

# Create the shortcut
$shortcut = $wshShell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $targetPath
$shortcut.Arguments = $arguments
$shortcut.WorkingDirectory = $workingDirectory
if ($iconPath) { $shortcut.IconLocation = $iconPath }
$shortcut.Save()

Write-Host "Shortcut created at $shortcutPath"
